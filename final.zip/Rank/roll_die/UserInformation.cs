﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace roll_die
{
    public partial class UserInformation : Form
    {
        string username;
        int money;
        bool check_rank;
        string rank;
        public UserInformation(string username, int money, bool check_rank)
        {
            InitializeComponent();
            this.username = username;
            this.money = money;
            this.check_rank = check_rank;
            if (check_rank == true)
                rank = "Đại Gia";
            else
                rank = "Tập Sự";
        }

        private void UserInformation_Load(object sender, EventArgs e)
        {
            tbUsername.Text = username;
            tbMoney.Text = money.ToString();
            tbRank.Text = rank;
        }
    }
}
