﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NetComm;

namespace Server_Tai_Xiu
{
    public partial class HostChat : Form
    {
        public NetComm.Host Server;
        public HostChat()
        {

            InitializeComponent();
            
             //Initialize the Server object, connection will use the 2020 port number
             //Starts listening for incoming clients
            
            //Adding event handling methods, to handle the server messages

        }

        public void Action()
        {
            Server = new NetComm.Host(2022);
            Server.onConnection += new NetComm.Host.onConnectionEventHandler(Server_onConnection);
            //Server.lostConnection += new NetComm.Host.lostConnectionEventHandler(Server_lostConnection);
            Server.DataReceived += new NetComm.Host.DataReceivedEventHandler(Server_DataReceived);
            Server.StartConnection();
        
        }

        //private void MainDisplay_FormClosing(object sender, FormClosingEventArgs e)
        //{
        //    Server.CloseConnection(); //Closes all of the opened connections and stops listening
        //}

        void Server_DataReceived(string ID, byte[] Data)
        {
            Log.AppendText(ID + ": " + ConvertBytesToString(Data) + "\r\n"); //Updates the log when a new message arrived, converting the Data bytes to a string
            string temp=ID+": "+ConvertBytesToString(Data);
            Server.Brodcast(ConvertStringToBytes(temp));
        }

        void Server_lostConnection(string id)
        {
            if (Log.IsDisposed) return; //Fixes the invoke error
            Log.AppendText(id + " disconnected \r\n" ); //Updates the log textbox when user leaves the room
        }//+ Environment.NewLine

        void Server_onConnection(string id)
        {
            Log.AppendText(id + " connected! \r\n" ); //Updates the log textbox when new user joined
        }

        string ConvertBytesToString(byte[] bytes)
        {
            return ASCIIEncoding.ASCII.GetString(bytes);
        }
        byte[] ConvertStringToBytes(string str)
        {
            return ASCIIEncoding.ASCII.GetBytes(str);
        }
    }
}
