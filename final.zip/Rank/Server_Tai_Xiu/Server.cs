﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using NetComm;
namespace Server_Tai_Xiu
{
    public partial class Server : Form
    {
        public int randomnum1;
        public int randomnum2;
        public int randomnum3;
        const int MaxConection = 10;
        static int ConnectionCount = 0;
        Socket server;
        public string IPServer = "127.0.0.1";
        public int PortServer = 9090;
        public const int BUFFER = 1024;
        Random dice = new Random();
        int time_trochoi = 30;
        public string Time_Transfer;
        public string ResultRandom;
        int time_cho = 10;
        int index = 0;
        int result;
        List<Socket> ListClient=new List<Socket>();
        List<int> ListResultRandom =new List<int>();
        public Server()
        {
            InitializeComponent();
            lbTime_cho.Hide();
        }


        private void tai_xiu_nhapnhay_Tick(object sender, EventArgs e)
        {
            Random ran = new Random();
            int col1 = ran.Next(0, 255);
            int col2 = ran.Next(0, 255);
            int col3 = ran.Next(0, 255);
            if (result >= 3 && result <= 10)
                lbXiu.ForeColor = Color.FromArgb(col1, col2, col3);
            else if (result > 10)
                lbTai.ForeColor = Color.FromArgb(col1, col2, col3);
        }


        private void time60_Tick(object sender, EventArgs e)
        {
            time_trochoi--;
            Time_Transfer = time_trochoi.ToString();
            if (time_trochoi < 10)
                lbTime.Text = "0" + time_trochoi.ToString();
            else
                lbTime.Text = time_trochoi.ToString();
            if (time_trochoi == 0)
            {
                //SendObject("Da dem xong random");
                lbTime.Hide();
                lbTime_cho.Show();
                time10.Start();
                tai_xiu_nhapnhay.Start();
                time60.Stop();
                if (index == 8)
                {
                    for (int j = 0; j < 7; j++)
                    {
                        iconRed_White.Images[j] = iconRed_White.Images[j + 1];
                        //listviewResult.LargeImageList = iconRed_White;
                    }
                    //listviewResult.Items.RemoveAt(7);
                    iconRed_White.Images.RemoveAt(7);
                    index--;
                }
                iconRed_White.ImageSize = new Size(40, 40);
                randomnum1 = dice.Next(1, 7);
                ListResultRandom.Add(randomnum1);
                randomnum2 = dice.Next(1, 7);
                ListResultRandom.Add(randomnum2);
                randomnum3 = dice.Next(1, 7);
                ListResultRandom.Add(randomnum3);
                
                result = randomnum1 + randomnum2 + randomnum3;

                switch (randomnum1)
                {
                    case 1:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 2:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_2.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 3:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_3.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 4:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_4.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 5:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_5.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 6:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_6.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    default:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                }
                switch (randomnum2)
                {
                    case 1:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 2:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_2.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 3:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_3.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 4:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_4.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 5:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_5.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 6:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_6.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    default:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                }
                switch (randomnum3)
                {
                    case 1:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 2:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_2.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 3:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_3.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 4:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_4.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 5:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_5.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 6:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_6.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    default:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                }


                //ListViewItem itemnew = new ListViewItem();
                ResultRandom = result.ToString();
                //MessageBox.Show(ResultRandom, "Result RANDOM");
                foreach (var user in ListClient)
                {
                    SendObject(ResultRandom,user);
                    SendObject(ListResultRandom, user);
                }

            }
        }
        private void time10_Tick(object sender, EventArgs e)
        {
            ListResultRandom.Clear();
            lbTime_cho.Show();
            time_cho--;
            lbTime_cho.Text = time_cho.ToString();
            if (time_cho == 0)
            {
                time_trochoi = 30;
                lbTime.Text = "30";
                time60.Start();
                time10.Stop();
                tai_xiu_nhapnhay.Stop();
                lbTime.Show();
                lbTime_cho.Hide();
                time_cho = 10;
                lbTime_cho.Text = "10";
                //btCuocXiu.Enabled = true;
                //btCuocTai.Enabled = true;
                lbXiu.ForeColor = Color.Red;
                lbTai.ForeColor = Color.Black;
                result = 0;
            }
        }
       
        private void Server_Load(object sender, EventArgs e)
        {

            CreateServer();
            //Chat
            //HostChat hostChat = new HostChat();
            //    hostChat.Show();
            //    
            //    hostChat.Action();

            Thread listenThread = new Thread(() =>
            {
                while (true)
                {
                    //Thread.Sleep(500);//ngu trong nua giay
                    try
                    {
                        Listen();
                        break;
                    }
                    catch
                    {

                    }
                }

            });
            
            listenThread.IsBackground = true;
            listenThread.Start();
            time60.Start();   
        }

        //==================NETWORK=========================
        void Listen()
        {
            string data = (string)ReceiveObject();
            MessageBox.Show(data);
        }




        public void CreateServer()
        {
            var IPLocal = IPAddress.Any;

            IPEndPoint ipendpoint = new IPEndPoint(IPLocal, PortServer);
            var listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            listener.Bind(ipendpoint);

            listener.Listen(10);// 10 la backlog--> so luong toi da yeu cau ket noi 
            while (ConnectionCount < MaxConection)
            {
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                ConnectionCount++;
                Thread accepClient = new Thread(() =>//truyen vao object, tra ve kieu void 
                {

                    server = listener.Accept();
                    ListClient.Insert(0, server);//Them Client vao dau list
                    SendObject(Time_Transfer);



                });
                accepClient.IsBackground = true;//Tự tắt khi chương trình tắt 
                accepClient.Start();
            }

        }
        public bool SendObject(object data)
        {
            byte[] Data = ChuyenVeByte(data);

            return SendData(server, Data);
        }
        public bool SendObject(object data, Socket user)
        {
            byte[] Data = ChuyenVeByte(data);

            return SendData(user, Data);
        }
        
        public object ReceiveObject()
        {
            byte[] receivedata = new byte[BUFFER];

            bool KetQuaReceive = ReceiveData(server, receivedata);
            return ChuyenVeObject(receivedata);



        }
        //Hàm gửi dữ liệu 
        private bool SendData(Socket target, byte[] data)
        {
            return target.Send(data) == 1 ? true : false;
        }

        //Hàm nhận dữ liệu 

        private bool ReceiveData(Socket target, byte[] data)
        {

            return target.Receive(data) == 1 ? true : false;
        }
        // Phân tich 1 object thành 1 mảng byte
        public byte[] ChuyenVeByte(object x)
        {
            MemoryStream memoryStream = new MemoryStream();// Tạo Stream để lưu trữ 
            BinaryFormatter bf1 = new BinaryFormatter();// Format kiểu byte
            bf1.Serialize(memoryStream, x);//Phân tách đối tượng theo kiểu byte
            return memoryStream.ToArray();
        }

        //Chuyển 1 mảng byte về lại thành object 
        public object ChuyenVeObject(byte[] ByteArray)
        {
            MemoryStream memoryStream = new MemoryStream(ByteArray);
            BinaryFormatter bf1 = new BinaryFormatter();
            memoryStream.Position = 0;// Bắt đầu từ vị trí 0
            return bf1.Deserialize(memoryStream);
        }

        private void lbTime_Click(object sender, EventArgs e)
        {

        }

   
    }
}
