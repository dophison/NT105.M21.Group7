﻿using System.Windows.Forms;

namespace Server_Tai_Xiu
{
    partial class Server
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Server));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbTime = new System.Windows.Forms.Label();
            this.time60 = new System.Windows.Forms.Timer(this.components);
            this.iconRed_White = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbTai = new System.Windows.Forms.Label();
            this.lbXiu = new System.Windows.Forms.Label();
            this.time10 = new System.Windows.Forms.Timer(this.components);
            this.lbTime_cho = new System.Windows.Forms.Label();
            this.tai_xiu_nhapnhay = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(410, 299);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(466, 187);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(90, 88);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // lbTime
            // 
            this.lbTime.AutoSize = true;
            this.lbTime.BackColor = System.Drawing.Color.Green;
            this.lbTime.Font = new System.Drawing.Font("Gill Sans Ultra Bold Condensed", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTime.ForeColor = System.Drawing.Color.Coral;
            this.lbTime.Image = global::Server_Tai_Xiu.Properties.Resources._60;
            this.lbTime.Location = new System.Drawing.Point(461, 11);
            this.lbTime.Name = "lbTime";
            this.lbTime.Size = new System.Drawing.Size(139, 110);
            this.lbTime.TabIndex = 8;
            this.lbTime.Text = "30";
            this.lbTime.Click += new System.EventHandler(this.lbTime_Click);
            // 
            // time60
            // 
            this.time60.Interval = 1000;
            this.time60.Tick += new System.EventHandler(this.time60_Tick);
            // 
            // iconRed_White
            // 
            this.iconRed_White.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.iconRed_White.ImageSize = new System.Drawing.Size(40, 40);
            this.iconRed_White.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(526, 299);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(87, 88);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // lbTai
            // 
            this.lbTai.AutoSize = true;
            this.lbTai.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbTai.Font = new System.Drawing.Font("Stencil", 55.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTai.ForeColor = System.Drawing.Color.Black;
            this.lbTai.Image = global::Server_Tai_Xiu.Properties.Resources.Tai;
            this.lbTai.Location = new System.Drawing.Point(161, 97);
            this.lbTai.Name = "lbTai";
            this.lbTai.Size = new System.Drawing.Size(197, 110);
            this.lbTai.TabIndex = 10;
            this.lbTai.Text = "Tài";
            this.lbTai.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbXiu
            // 
            this.lbXiu.AutoSize = true;
            this.lbXiu.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbXiu.Font = new System.Drawing.Font("Stencil", 55.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbXiu.ForeColor = System.Drawing.Color.Red;
            this.lbXiu.Image = global::Server_Tai_Xiu.Properties.Resources.Xiu;
            this.lbXiu.Location = new System.Drawing.Point(675, 94);
            this.lbXiu.Name = "lbXiu";
            this.lbXiu.Size = new System.Drawing.Size(188, 110);
            this.lbXiu.TabIndex = 11;
            this.lbXiu.Text = "Xỉu";
            // 
            // time10
            // 
            this.time10.Interval = 1000;
            this.time10.Tick += new System.EventHandler(this.time10_Tick);
            // 
            // lbTime_cho
            // 
            this.lbTime_cho.AutoSize = true;
            this.lbTime_cho.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbTime_cho.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold);
            this.lbTime_cho.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbTime_cho.Image = global::Server_Tai_Xiu.Properties.Resources._10;
            this.lbTime_cho.Location = new System.Drawing.Point(596, 121);
            this.lbTime_cho.Name = "lbTime_cho";
            this.lbTime_cho.Size = new System.Drawing.Size(40, 31);
            this.lbTime_cho.TabIndex = 26;
            this.lbTime_cho.Text = "10";
            // 
            // Server
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BackgroundImage = global::Server_Tai_Xiu.Properties.Resources.BackGround;
            this.ClientSize = new System.Drawing.Size(1047, 494);
            this.Controls.Add(this.lbTime_cho);
            this.Controls.Add(this.lbXiu);
            this.Controls.Add(this.lbTai);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lbTime);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Server";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Server_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private Label lbTime;
        private System.Windows.Forms.Timer time60;
        public ImageList iconRed_White;
        private PictureBox pictureBox2;
        private Label lbTai;
        private Label lbXiu;
        private System.Windows.Forms.Timer time10;
        private Label lbTime_cho;
        private System.Windows.Forms.Timer tai_xiu_nhapnhay;
    }
}

