﻿namespace roll_die
{
    partial class PlayGame
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlayGame));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbTime = new System.Windows.Forms.Label();
            this.time60 = new System.Windows.Forms.Timer(this.components);
            this.iconRed_White = new System.Windows.Forms.ImageList(this.components);
            this.listviewResult = new System.Windows.Forms.ListView();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbTai = new System.Windows.Forms.Label();
            this.lbXiu = new System.Windows.Forms.Label();
            this.btCuocTai = new System.Windows.Forms.Button();
            this.btCuocXiu = new System.Windows.Forms.Button();
            this.bt10K = new System.Windows.Forms.Button();
            this.bt20K = new System.Windows.Forms.Button();
            this.bt50K = new System.Windows.Forms.Button();
            this.bt100K = new System.Windows.Forms.Button();
            this.btXacNhanCuoc = new System.Windows.Forms.Button();
            this.btExitCuoc = new System.Windows.Forms.Button();
            this.btAIn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.time10 = new System.Windows.Forms.Timer(this.components);
            this.lbTime_cho = new System.Windows.Forms.Label();
            this.tai_xiu_nhapnhay = new System.Windows.Forms.Timer(this.components);
            this.btn_UserInfor = new System.Windows.Forms.Button();
            this.btn_HuongDan = new System.Windows.Forms.Button();
            this.btn_Out = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbSodu_User = new System.Windows.Forms.Label();
            this.lbName_User = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(444, 220);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 70);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(491, 144);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(70, 70);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // lbTime
            // 
            this.lbTime.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbTime.Font = new System.Drawing.Font("Gill Sans Ultra Bold Condensed", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.lbTime.Image = global::roll_die.Properties.Resources._60;
            this.lbTime.Location = new System.Drawing.Point(462, 9);
            this.lbTime.Name = "lbTime";
            this.lbTime.Size = new System.Drawing.Size(139, 103);
            this.lbTime.TabIndex = 8;
            this.lbTime.Text = "60";
            // 
            // time60
            // 
            this.time60.Interval = 1000;
            this.time60.Tick += new System.EventHandler(this.time60_click);
            // 
            // iconRed_White
            // 
            this.iconRed_White.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.iconRed_White.ImageSize = new System.Drawing.Size(40, 40);
            this.iconRed_White.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // listviewResult
            // 
            this.listviewResult.BackColor = System.Drawing.Color.White;
            this.listviewResult.ForeColor = System.Drawing.Color.Yellow;
            this.listviewResult.Location = new System.Drawing.Point(128, 319);
            this.listviewResult.Name = "listviewResult";
            this.listviewResult.Scrollable = false;
            this.listviewResult.ShowItemToolTips = true;
            this.listviewResult.Size = new System.Drawing.Size(788, 49);
            this.listviewResult.TabIndex = 8;
            this.listviewResult.UseCompatibleStateImageBehavior = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(542, 220);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(70, 70);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // lbTai
            // 
            this.lbTai.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbTai.Font = new System.Drawing.Font("Stencil", 55.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lbTai.ForeColor = System.Drawing.Color.Black;
            this.lbTai.Image = global::roll_die.Properties.Resources.Tai;
            this.lbTai.Location = new System.Drawing.Point(148, 97);
            this.lbTai.Name = "lbTai";
            this.lbTai.Size = new System.Drawing.Size(200, 101);
            this.lbTai.TabIndex = 10;
            this.lbTai.Text = "Tài";
            // 
            // lbXiu
            // 
            this.lbXiu.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbXiu.Font = new System.Drawing.Font("Stencil", 58.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lbXiu.ForeColor = System.Drawing.Color.Red;
            this.lbXiu.Image = global::roll_die.Properties.Resources.Xiu;
            this.lbXiu.Location = new System.Drawing.Point(671, 97);
            this.lbXiu.Name = "lbXiu";
            this.lbXiu.Size = new System.Drawing.Size(197, 101);
            this.lbXiu.TabIndex = 11;
            this.lbXiu.Text = "Xỉu";
            // 
            // btCuocTai
            // 
            this.btCuocTai.BackColor = System.Drawing.Color.Fuchsia;
            this.btCuocTai.Font = new System.Drawing.Font("Arial Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btCuocTai.Location = new System.Drawing.Point(198, 220);
            this.btCuocTai.Name = "btCuocTai";
            this.btCuocTai.Size = new System.Drawing.Size(104, 41);
            this.btCuocTai.TabIndex = 12;
            this.btCuocTai.Text = "Bet";
            this.btCuocTai.UseVisualStyleBackColor = false;
            this.btCuocTai.Click += new System.EventHandler(this.btCuocTai_Click);
            // 
            // btCuocXiu
            // 
            this.btCuocXiu.BackColor = System.Drawing.Color.Fuchsia;
            this.btCuocXiu.Font = new System.Drawing.Font("Arial Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btCuocXiu.Location = new System.Drawing.Point(728, 220);
            this.btCuocXiu.Name = "btCuocXiu";
            this.btCuocXiu.Size = new System.Drawing.Size(104, 41);
            this.btCuocXiu.TabIndex = 15;
            this.btCuocXiu.Text = "Bet";
            this.btCuocXiu.UseVisualStyleBackColor = false;
            this.btCuocXiu.Click += new System.EventHandler(this.btCuocXiu_Click);
            // 
            // bt10K
            // 
            this.bt10K.BackColor = System.Drawing.Color.Salmon;
            this.bt10K.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt10K.Location = new System.Drawing.Point(208, 393);
            this.bt10K.Name = "bt10K";
            this.bt10K.Size = new System.Drawing.Size(94, 41);
            this.bt10K.TabIndex = 16;
            this.bt10K.Text = "10K";
            this.bt10K.UseVisualStyleBackColor = false;
            this.bt10K.Click += new System.EventHandler(this.bt10K_Click);
            // 
            // bt20K
            // 
            this.bt20K.BackColor = System.Drawing.Color.Salmon;
            this.bt20K.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt20K.Location = new System.Drawing.Point(388, 393);
            this.bt20K.Name = "bt20K";
            this.bt20K.Size = new System.Drawing.Size(94, 41);
            this.bt20K.TabIndex = 17;
            this.bt20K.Text = "20K";
            this.bt20K.UseVisualStyleBackColor = false;
            this.bt20K.Click += new System.EventHandler(this.bt20K_Click);
            // 
            // bt50K
            // 
            this.bt50K.BackColor = System.Drawing.Color.Salmon;
            this.bt50K.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt50K.Location = new System.Drawing.Point(566, 393);
            this.bt50K.Name = "bt50K";
            this.bt50K.Size = new System.Drawing.Size(94, 41);
            this.bt50K.TabIndex = 18;
            this.bt50K.Text = "50K";
            this.bt50K.UseVisualStyleBackColor = false;
            this.bt50K.Click += new System.EventHandler(this.bt50K_Click);
            // 
            // bt100K
            // 
            this.bt100K.BackColor = System.Drawing.Color.Salmon;
            this.bt100K.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt100K.Location = new System.Drawing.Point(738, 393);
            this.bt100K.Name = "bt100K";
            this.bt100K.Size = new System.Drawing.Size(94, 41);
            this.bt100K.TabIndex = 19;
            this.bt100K.Text = "100K";
            this.bt100K.UseVisualStyleBackColor = false;
            this.bt100K.Click += new System.EventHandler(this.bt100K_Click);
            // 
            // btXacNhanCuoc
            // 
            this.btXacNhanCuoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btXacNhanCuoc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btXacNhanCuoc.Location = new System.Drawing.Point(444, 458);
            this.btXacNhanCuoc.Name = "btXacNhanCuoc";
            this.btXacNhanCuoc.Size = new System.Drawing.Size(168, 64);
            this.btXacNhanCuoc.TabIndex = 20;
            this.btXacNhanCuoc.Text = "Xác Nhận Cược";
            this.btXacNhanCuoc.UseVisualStyleBackColor = false;
            this.btXacNhanCuoc.Click += new System.EventHandler(this.btXacNhanCuoc_Click);
            // 
            // btExitCuoc
            // 
            this.btExitCuoc.BackColor = System.Drawing.Color.Red;
            this.btExitCuoc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btExitCuoc.Location = new System.Drawing.Point(654, 472);
            this.btExitCuoc.Name = "btExitCuoc";
            this.btExitCuoc.Size = new System.Drawing.Size(113, 48);
            this.btExitCuoc.TabIndex = 21;
            this.btExitCuoc.Text = "Exit";
            this.btExitCuoc.UseVisualStyleBackColor = false;
            this.btExitCuoc.Click += new System.EventHandler(this.btExitCuoc_Click);
            // 
            // btAIn
            // 
            this.btAIn.BackColor = System.Drawing.Color.Violet;
            this.btAIn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btAIn.Location = new System.Drawing.Point(288, 474);
            this.btAIn.Name = "btAIn";
            this.btAIn.Size = new System.Drawing.Size(113, 48);
            this.btAIn.TabIndex = 22;
            this.btAIn.Text = "ALL IN";
            this.btAIn.UseVisualStyleBackColor = false;
            this.btAIn.Click += new System.EventHandler(this.btAIn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(3, 499);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 23);
            this.label2.TabIndex = 24;
            this.label2.Text = "Số dư :";
            // 
            // time10
            // 
            this.time10.Interval = 1000;
            this.time10.Tick += new System.EventHandler(this.time10_click);
            // 
            // lbTime_cho
            // 
            this.lbTime_cho.AutoSize = true;
            this.lbTime_cho.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbTime_cho.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbTime_cho.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.lbTime_cho.Image = global::roll_die.Properties.Resources._10;
            this.lbTime_cho.Location = new System.Drawing.Point(592, 123);
            this.lbTime_cho.Name = "lbTime_cho";
            this.lbTime_cho.Size = new System.Drawing.Size(40, 31);
            this.lbTime_cho.TabIndex = 26;
            this.lbTime_cho.Text = "10";
            // 
            // tai_xiu_nhapnhay
            // 
            this.tai_xiu_nhapnhay.Tick += new System.EventHandler(this.tai_xiu_nhapnhay_Tick);
            // 
            // btn_UserInfor
            // 
            this.btn_UserInfor.Image = global::roll_die.Properties.Resources.user2;
            this.btn_UserInfor.Location = new System.Drawing.Point(30, 14);
            this.btn_UserInfor.Name = "btn_UserInfor";
            this.btn_UserInfor.Size = new System.Drawing.Size(88, 75);
            this.btn_UserInfor.TabIndex = 27;
            this.btn_UserInfor.UseVisualStyleBackColor = true;
            this.btn_UserInfor.Click += new System.EventHandler(this.btn_UserInfor_Click);
            // 
            // btn_HuongDan
            // 
            this.btn_HuongDan.Font = new System.Drawing.Font("MV Boli", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_HuongDan.Location = new System.Drawing.Point(916, 14);
            this.btn_HuongDan.Name = "btn_HuongDan";
            this.btn_HuongDan.Size = new System.Drawing.Size(71, 75);
            this.btn_HuongDan.TabIndex = 28;
            this.btn_HuongDan.Text = "?";
            this.btn_HuongDan.UseVisualStyleBackColor = true;
            this.btn_HuongDan.Click += new System.EventHandler(this.btn_HuongDan_Click);
            // 
            // btn_Out
            // 
            this.btn_Out.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Out.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Out.ForeColor = System.Drawing.Color.Red;
            this.btn_Out.Location = new System.Drawing.Point(893, 472);
            this.btn_Out.Name = "btn_Out";
            this.btn_Out.Size = new System.Drawing.Size(94, 47);
            this.btn_Out.TabIndex = 29;
            this.btn_Out.Text = "Out";
            this.btn_Out.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_Out.UseVisualStyleBackColor = false;
            this.btn_Out.Click += new System.EventHandler(this.btn_Out_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(3, 458);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 23);
            this.label1.TabIndex = 31;
            this.label1.Text = "Name :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(78, 502);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 20);
            this.label3.TabIndex = 32;
            // 
            // lbSodu_User
            // 
            this.lbSodu_User.AutoSize = true;
            this.lbSodu_User.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbSodu_User.Location = new System.Drawing.Point(84, 499);
            this.lbSodu_User.Name = "lbSodu_User";
            this.lbSodu_User.Size = new System.Drawing.Size(20, 23);
            this.lbSodu_User.TabIndex = 33;
            this.lbSodu_User.Text = "0";
            // 
            // lbName_User
            // 
            this.lbName_User.AutoSize = true;
            this.lbName_User.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbName_User.Location = new System.Drawing.Point(83, 457);
            this.lbName_User.Name = "lbName_User";
            this.lbName_User.Size = new System.Drawing.Size(104, 23);
            this.lbName_User.TabIndex = 34;
            this.lbName_User.Text = "Anonymous";
            // 
            // PlayGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BackgroundImage = global::roll_die.Properties.Resources.BackGround;
            this.ClientSize = new System.Drawing.Size(1049, 539);
            this.Controls.Add(this.lbName_User);
            this.Controls.Add(this.lbSodu_User);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Out);
            this.Controls.Add(this.btn_HuongDan);
            this.Controls.Add(this.btn_UserInfor);
            this.Controls.Add(this.lbTime_cho);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btAIn);
            this.Controls.Add(this.btExitCuoc);
            this.Controls.Add(this.btXacNhanCuoc);
            this.Controls.Add(this.bt100K);
            this.Controls.Add(this.bt50K);
            this.Controls.Add(this.bt20K);
            this.Controls.Add(this.bt10K);
            this.Controls.Add(this.btCuocXiu);
            this.Controls.Add(this.btCuocTai);
            this.Controls.Add(this.lbXiu);
            this.Controls.Add(this.lbTai);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.listviewResult);
            this.Controls.Add(this.lbTime);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.Name = "PlayGame";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private Label lbTime;
        private System.Windows.Forms.Timer time60;
        private ListView listviewResult;
        public ImageList iconRed_White;
        private PictureBox pictureBox2;
        private Label lbTai;
        private Label lbXiu;
        private Button btCuocTai;
        private Button btCuocXiu;
        private Button bt10K;
        private Button bt20K;
        private Button bt50K;
        private Button bt100K;
        private Button btXacNhanCuoc;
        private Button btExitCuoc;
        private Button btAIn;
        private Label label2;
        private System.Windows.Forms.Timer time10;
        private Label lbTime_cho;
        private System.Windows.Forms.Timer tai_xiu_nhapnhay;
        private Button btn_UserInfor;
        private Button btn_HuongDan;
        private Button btn_Out;
        private Label label1;
        private Label label3;
        private Label lbSodu_User;
        private Label lbName_User;
    }
}