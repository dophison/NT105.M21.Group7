﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Net;
using System.Threading;
namespace roll_die
{

    public class SocketManager
    {

        #region client
        Socket client;
        
        //Hàm kết nối giữa Client với Server
        public bool ConnetServer()
        {
            IPEndPoint ServerIpendpoint = new IPEndPoint(IPAddress.Parse(IP), Port);
            var client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                client.Connect(ServerIpendpoint);
                return true;
            }
            catch
            {
                return false;
            }
        }
        #endregion

        #region server
        Socket server;
        
        //Tạo Server 
        public void CreateServer()
        {
            var IPLocal = IPAddress.Any;
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint ipendpoint = new IPEndPoint(IPLocal, Port);
            var listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            listener.Bind(ipendpoint);

            listener.Listen(10);// 10 la backlog--> so luong toi da yeu cau ket noi 

            Thread accepClient = new Thread(() =>//truyen vao object, tra ve kieu void 
            {
                server = listener.Accept();
            });
            accepClient.IsBackground = true;//Tự tắt khi chương trình tắt 
            accepClient.Start();
        }

       #endregion

        #region Both
        public string IP = "127.0.0.1";
        public int Port = 9090;
        public const int BUFFER = 1024;
        public bool isClient;
      

        public bool SendObject(object data)
        {
            byte[] Data = ChuyenVeByte(data);
            
           if (isClient == true)//Nếu là client
            {
                return SendData(client, Data);
            }
            else//Nếu là server
            {
                return SendData(server, Data);
            }
        }

        public object ReceiveObject()
        {
            byte[] receivedata = new byte[BUFFER];

            if (isClient == true)//Nếu là client
            {
                
                bool KetQuaReceive = ReceiveData(client, receivedata);
                if (KetQuaReceive == true)
                {
                    return ChuyenVeObject(receivedata);
                }
                else
                {
                    MessageBox.Show("Error....");
                    return null;
                }
            
                
            }
            else//Nếu là server 
            {
           
                bool KetQuaReceive = ReceiveData(server, receivedata);
                if (KetQuaReceive == true)
                {
                    return ChuyenVeObject(receivedata);
                }
                else
                {
                    MessageBox.Show("Error....");
                    return null;
                }
            }

        }
        //Hàm gửi dữ liệu 
        private bool SendData(Socket target, byte[] data)
        {
            return target.Send(data) == 1 ? true : false;
        }

        //Hàm nhận dữ liệu 

        private bool ReceiveData(Socket target, byte[] data)
        {

            return target.Receive(data) == 1 ? true : false;
        }
        // Phân tich 1 object thành 1 mảng byte
        public byte[] ChuyenVeByte(object x)
        {
            MemoryStream memoryStream = new MemoryStream();// Tạo Stream để lưu trữ 
            BinaryFormatter bf1 = new BinaryFormatter();// Format kiểu byte
            bf1.Serialize(memoryStream, x);//Phân tách đối tượng theo kiểu byte
            return memoryStream.ToArray();
        }

        //Chuyển 1 mảng byte về lại thành object 
        public object ChuyenVeObject(byte[] ByteArray)
        {
            MemoryStream memoryStream = new MemoryStream(ByteArray);
            BinaryFormatter bf1 = new BinaryFormatter();
            memoryStream.Position = 0;// Bắt đầu từ vị trí 0
            return bf1.Deserialize(memoryStream);
        }
        // Lấy địa chỉ IPv4 của card mạng đang dùng
        public string GetIPv4(NetworkInterfaceType _type)
        {
            string output = "";
            foreach (NetworkInterface item in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (item.NetworkInterfaceType == _type && item.OperationalStatus == OperationalStatus.Up)

                {
                    foreach (UnicastIPAddressInformation ip in item.GetIPProperties().UnicastAddresses)
                    {
                        if (ip.Address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            output = ip.Address.ToString();
                        }
                    }
                }
            }
            return output;
        }

        #endregion
    }
}

