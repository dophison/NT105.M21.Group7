﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace roll_die
{
    public partial class UserInformation : Form
    {
        string username;
        int money;
        public UserInformation(string username, int money)
        {
            InitializeComponent();
            this.username = username;
            this.money = money;
        }

        private void UserInformation_Load(object sender, EventArgs e)
        {
            tbUsername.Text = username;
            tbMoney.Text = money.ToString();
            //Con cai rank chua lam
        }
    }
}
