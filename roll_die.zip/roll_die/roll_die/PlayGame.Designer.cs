﻿namespace roll_die
{
    partial class PlayGame
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlayGame));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbTime = new System.Windows.Forms.Label();
            this.time60 = new System.Windows.Forms.Timer(this.components);
            this.iconRed_White = new System.Windows.Forms.ImageList(this.components);
            this.listviewResult = new System.Windows.Forms.ListView();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbTai = new System.Windows.Forms.Label();
            this.lbXiu = new System.Windows.Forms.Label();
            this.btCuocTai = new System.Windows.Forms.Button();
            this.lbTaiCoin = new System.Windows.Forms.Label();
            this.lbXiuCoin = new System.Windows.Forms.Label();
            this.btCuocXiu = new System.Windows.Forms.Button();
            this.bt10K = new System.Windows.Forms.Button();
            this.bt20K = new System.Windows.Forms.Button();
            this.bt50K = new System.Windows.Forms.Button();
            this.bt100K = new System.Windows.Forms.Button();
            this.btXacNhanCuoc = new System.Windows.Forms.Button();
            this.btExitCuoc = new System.Windows.Forms.Button();
            this.btAIn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbSodu_User = new System.Windows.Forms.Label();
            this.time10 = new System.Windows.Forms.Timer(this.components);
            this.lbTime_cho = new System.Windows.Forms.Label();
            this.tai_xiu_nhapnhay = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(428, 186);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 70);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(469, 110);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(70, 70);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // lbTime
            // 
            this.lbTime.Font = new System.Drawing.Font("Gill Sans Ultra Bold Condensed", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbTime.ForeColor = System.Drawing.Color.Coral;
            this.lbTime.Location = new System.Drawing.Point(434, 4);
            this.lbTime.Name = "lbTime";
            this.lbTime.Size = new System.Drawing.Size(149, 103);
            this.lbTime.TabIndex = 8;
            this.lbTime.Text = "60";
            // 
            // time60
            // 
            this.time60.Interval = 1000;
            this.time60.Tick += new System.EventHandler(this.time60_click);
            // 
            // iconRed_White
            // 
            this.iconRed_White.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.iconRed_White.ImageSize = new System.Drawing.Size(40, 40);
            this.iconRed_White.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // listviewResult
            // 
            this.listviewResult.BackColor = System.Drawing.Color.White;
            this.listviewResult.ForeColor = System.Drawing.Color.Yellow;
            this.listviewResult.Location = new System.Drawing.Point(110, 300);
            this.listviewResult.Name = "listviewResult";
            this.listviewResult.Scrollable = false;
            this.listviewResult.ShowItemToolTips = true;
            this.listviewResult.Size = new System.Drawing.Size(788, 49);
            this.listviewResult.TabIndex = 8;
            this.listviewResult.UseCompatibleStateImageBehavior = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(513, 186);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(70, 70);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // lbTai
            // 
            this.lbTai.Font = new System.Drawing.Font("Stencil", 52.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lbTai.ForeColor = System.Drawing.Color.Black;
            this.lbTai.Location = new System.Drawing.Point(136, 90);
            this.lbTai.Name = "lbTai";
            this.lbTai.Size = new System.Drawing.Size(197, 101);
            this.lbTai.TabIndex = 10;
            this.lbTai.Text = "Tài";
            // 
            // lbXiu
            // 
            this.lbXiu.Font = new System.Drawing.Font("Stencil", 52.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lbXiu.ForeColor = System.Drawing.Color.Red;
            this.lbXiu.Location = new System.Drawing.Point(701, 90);
            this.lbXiu.Name = "lbXiu";
            this.lbXiu.Size = new System.Drawing.Size(197, 101);
            this.lbXiu.TabIndex = 11;
            this.lbXiu.Text = "Xỉu";
            // 
            // btCuocTai
            // 
            this.btCuocTai.Location = new System.Drawing.Point(184, 245);
            this.btCuocTai.Name = "btCuocTai";
            this.btCuocTai.Size = new System.Drawing.Size(94, 29);
            this.btCuocTai.TabIndex = 12;
            this.btCuocTai.Text = "Bet";
            this.btCuocTai.UseVisualStyleBackColor = true;
            this.btCuocTai.Click += new System.EventHandler(this.btCuocTai_Click);
            // 
            // lbTaiCoin
            // 
            this.lbTaiCoin.AutoSize = true;
            this.lbTaiCoin.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbTaiCoin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbTaiCoin.Location = new System.Drawing.Point(217, 191);
            this.lbTaiCoin.Name = "lbTaiCoin";
            this.lbTaiCoin.Size = new System.Drawing.Size(26, 31);
            this.lbTaiCoin.TabIndex = 13;
            this.lbTaiCoin.Text = "0";
            // 
            // lbXiuCoin
            // 
            this.lbXiuCoin.AutoSize = true;
            this.lbXiuCoin.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbXiuCoin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbXiuCoin.Location = new System.Drawing.Point(777, 186);
            this.lbXiuCoin.Name = "lbXiuCoin";
            this.lbXiuCoin.Size = new System.Drawing.Size(26, 31);
            this.lbXiuCoin.TabIndex = 14;
            this.lbXiuCoin.Text = "0";
            // 
            // btCuocXiu
            // 
            this.btCuocXiu.Location = new System.Drawing.Point(742, 245);
            this.btCuocXiu.Name = "btCuocXiu";
            this.btCuocXiu.Size = new System.Drawing.Size(94, 29);
            this.btCuocXiu.TabIndex = 15;
            this.btCuocXiu.Text = "Bet";
            this.btCuocXiu.UseVisualStyleBackColor = true;
            this.btCuocXiu.Click += new System.EventHandler(this.btCuocXiu_Click);
            // 
            // bt10K
            // 
            this.bt10K.Location = new System.Drawing.Point(217, 393);
            this.bt10K.Name = "bt10K";
            this.bt10K.Size = new System.Drawing.Size(94, 41);
            this.bt10K.TabIndex = 16;
            this.bt10K.Text = "10K";
            this.bt10K.UseVisualStyleBackColor = true;
            this.bt10K.Click += new System.EventHandler(this.bt10K_Click);
            // 
            // bt20K
            // 
            this.bt20K.Location = new System.Drawing.Point(370, 393);
            this.bt20K.Name = "bt20K";
            this.bt20K.Size = new System.Drawing.Size(94, 41);
            this.bt20K.TabIndex = 17;
            this.bt20K.Text = "20K";
            this.bt20K.UseVisualStyleBackColor = true;
            this.bt20K.Click += new System.EventHandler(this.bt20K_Click);
            // 
            // bt50K
            // 
            this.bt50K.Location = new System.Drawing.Point(542, 393);
            this.bt50K.Name = "bt50K";
            this.bt50K.Size = new System.Drawing.Size(94, 41);
            this.bt50K.TabIndex = 18;
            this.bt50K.Text = "50K";
            this.bt50K.UseVisualStyleBackColor = true;
            this.bt50K.Click += new System.EventHandler(this.bt50K_Click);
            // 
            // bt100K
            // 
            this.bt100K.Location = new System.Drawing.Point(701, 393);
            this.bt100K.Name = "bt100K";
            this.bt100K.Size = new System.Drawing.Size(94, 41);
            this.bt100K.TabIndex = 19;
            this.bt100K.Text = "100K";
            this.bt100K.UseVisualStyleBackColor = true;
            this.bt100K.Click += new System.EventHandler(this.bt100K_Click);
            // 
            // btXacNhanCuoc
            // 
            this.btXacNhanCuoc.Location = new System.Drawing.Point(428, 458);
            this.btXacNhanCuoc.Name = "btXacNhanCuoc";
            this.btXacNhanCuoc.Size = new System.Drawing.Size(155, 64);
            this.btXacNhanCuoc.TabIndex = 20;
            this.btXacNhanCuoc.Text = "Xác Nhận Cược";
            this.btXacNhanCuoc.UseVisualStyleBackColor = true;
            this.btXacNhanCuoc.Click += new System.EventHandler(this.btXacNhanCuoc_Click);
            // 
            // btExitCuoc
            // 
            this.btExitCuoc.Location = new System.Drawing.Point(612, 474);
            this.btExitCuoc.Name = "btExitCuoc";
            this.btExitCuoc.Size = new System.Drawing.Size(113, 48);
            this.btExitCuoc.TabIndex = 21;
            this.btExitCuoc.Text = "Exit";
            this.btExitCuoc.UseVisualStyleBackColor = true;
            this.btExitCuoc.Click += new System.EventHandler(this.btExitCuoc_Click);
            // 
            // btAIn
            // 
            this.btAIn.Location = new System.Drawing.Point(288, 474);
            this.btAIn.Name = "btAIn";
            this.btAIn.Size = new System.Drawing.Size(113, 48);
            this.btAIn.TabIndex = 22;
            this.btAIn.Text = "ALL IN";
            this.btAIn.UseVisualStyleBackColor = true;
            this.btAIn.Click += new System.EventHandler(this.btAIn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(30, 440);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 23;
            this.label1.Text = "Name_User";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(3, 474);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 23);
            this.label2.TabIndex = 24;
            this.label2.Text = "Số dư ha:";
            // 
            // lbSodu_User
            // 
            this.lbSodu_User.AutoSize = true;
            this.lbSodu_User.Font = new System.Drawing.Font("Yu Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbSodu_User.ForeColor = System.Drawing.Color.Red;
            this.lbSodu_User.Location = new System.Drawing.Point(95, 476);
            this.lbSodu_User.Name = "lbSodu_User";
            this.lbSodu_User.Size = new System.Drawing.Size(60, 22);
            this.lbSodu_User.TabIndex = 25;
            this.lbSodu_User.Text = "50000";
            // 
            // time10
            // 
            this.time10.Interval = 1000;
            this.time10.Tick += new System.EventHandler(this.time10_click);
            // 
            // lbTime_cho
            // 
            this.lbTime_cho.AutoSize = true;
            this.lbTime_cho.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbTime_cho.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbTime_cho.Location = new System.Drawing.Point(609, 110);
            this.lbTime_cho.Name = "lbTime_cho";
            this.lbTime_cho.Size = new System.Drawing.Size(27, 31);
            this.lbTime_cho.TabIndex = 26;
            this.lbTime_cho.Text = "5";
            // 
            // tai_xiu_nhapnhay
            // 
            this.tai_xiu_nhapnhay.Tick += new System.EventHandler(this.tai_xiu_nhapnhay_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(1009, 552);
            this.Controls.Add(this.lbTime_cho);
            this.Controls.Add(this.lbSodu_User);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btAIn);
            this.Controls.Add(this.btExitCuoc);
            this.Controls.Add(this.btXacNhanCuoc);
            this.Controls.Add(this.bt100K);
            this.Controls.Add(this.bt50K);
            this.Controls.Add(this.bt20K);
            this.Controls.Add(this.bt10K);
            this.Controls.Add(this.btCuocXiu);
            this.Controls.Add(this.lbXiuCoin);
            this.Controls.Add(this.lbTaiCoin);
            this.Controls.Add(this.btCuocTai);
            this.Controls.Add(this.lbXiu);
            this.Controls.Add(this.lbTai);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.listviewResult);
            this.Controls.Add(this.lbTime);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private Label lbTime;
        private System.Windows.Forms.Timer time60;
        private ListView listviewResult;
        public ImageList iconRed_White;
        private PictureBox pictureBox2;
        private Label lbTai;
        private Label lbXiu;
        private Button btCuocTai;
        private Label lbTaiCoin;
        private Label lbXiuCoin;
        private Button btCuocXiu;
        private Button bt10K;
        private Button bt20K;
        private Button bt50K;
        private Button bt100K;
        private Button btXacNhanCuoc;
        private Button btExitCuoc;
        private Button btAIn;
        private Label label1;
        private Label label2;
        private Label lbSodu_User;
        private System.Windows.Forms.Timer time10;
        private Label lbTime_cho;
        private System.Windows.Forms.Timer tai_xiu_nhapnhay;
    }
}