using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace roll_die
{
    public partial class Form1 : Form
    {
        Random dice = new Random();
        public Form1()
        {
            InitializeComponent();
            Set_Default();
        }

        private void Set_Default()
        {
            lbTaiCoin.Text = "0";
            lbXiuCoin.Text = "0";
            bt10K.Hide(); bt10K.BackColor = Color.White;
            bt20K.Hide(); bt20K.BackColor = Color.White;
            bt50K.Hide(); bt50K.BackColor = Color.White;
            bt100K.Hide(); bt100K.BackColor = Color.White;
            btAIn.Hide(); btAIn.BackColor = Color.White;
            btExitCuoc.Hide();
            btXacNhanCuoc.Hide();
        }

        private void Show_button()
        {
            bt10K.Show();
            bt20K.Show();
            bt50K.Show();
            bt100K.Show();
            btAIn.Show();
            btExitCuoc.Show();
            btXacNhanCuoc.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            time60.Start();
        }
        
        int time_trochoi = 60;
        int time_cho = 5;
        int index = 0;
        int result;
        private void time60_click(object sender, EventArgs e)
        {
            time_trochoi--;
            if(time_trochoi < 10)
                lbTime.Text = "0" + time_trochoi.ToString();
            else
                lbTime.Text = time_trochoi.ToString();
            if (time_trochoi == 0)
            {
                lbTime.Hide();
                lbTime_cho.Show();
                time10.Start();
                tai_xiu_nhapnhay.Start();
                time60.Stop();
                if (index == 8)
                {
                    for(int j = 0; j < 7; j++) {                                                                                            
                        iconRed_White.Images[j] = iconRed_White.Images[j + 1];
                        listviewResult.LargeImageList = iconRed_White;
                    }
                    listviewResult.Items.RemoveAt(7);                                                 
                    iconRed_White.Images.RemoveAt(7);
                    index--;
                }              
                iconRed_White.ImageSize = new Size(40, 40);
                int randomnum1 = dice.Next(1, 7);
                int randomnum2 = dice.Next(1, 7);
                int randomnum3 = dice.Next(1, 7);              
                result = randomnum1 + randomnum2 + randomnum3;
                ListViewItem itemnew = new ListViewItem();
                if (result <= 10) {                                               
                    
                    iconRed_White.Images.Add(new Bitmap(Application.StartupPath + "\\image\\2.png"));
                    itemnew.ImageIndex = index;                   
                    listviewResult.Items.Add(itemnew);
                    
                    if(btCuocTai.Enabled == false)
                    {
                        int tienthuong = int.Parse(btCuocXiu.Text)*2;
                        int getsodu = int.Parse(lbSodu_User.Text);
                        lbSodu_User.Text = (tienthuong+getsodu).ToString();
                    }

                }
                else {                                                                            
                    
                    iconRed_White.Images.Add(new Bitmap(Application.StartupPath + "\\image\\1.png"));
                    itemnew.ImageIndex = index;                   
                    listviewResult.Items.Add(itemnew);

                    if (btCuocXiu.Enabled == false)
                    {
                        int tienthuong = int.Parse(btCuocTai.Text)*2;
                        int getsodu = int.Parse(lbSodu_User.Text);
                        lbSodu_User.Text = (tienthuong + getsodu).ToString();
                    }

                }
                listviewResult.LargeImageList = iconRed_White;                                       
                index++;              
                switch (randomnum1)
                {
                    case 1:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 2:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_2.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 3:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_3.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 4:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_4.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 5:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_5.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 6:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_6.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    default:
                        pictureBox1.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                }
                switch (randomnum2)
                {
                    case 1:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 2:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_2.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 3:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_3.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 4:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_4.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 5:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_5.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 6:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_6.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    default:
                        pictureBox2.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                }
                switch (randomnum3)
                {
                    case 1:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 2:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_2.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 3:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_3.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 4:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_4.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 5:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_5.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    case 6:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_6.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                    default:
                        pictureBox3.ImageLocation = Application.StartupPath + "\\image\\dice_1.png";
                        pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
                        break;
                }             
                if (btCuocTai.Enabled == true)
                {
                    btCuocTai.Text = "Bet";
                    btCuocXiu.Enabled = true;
                }
                else
                {
                    btCuocXiu.Text = "Bet";
                    btCuocTai.Enabled = true;
                }
                Set_Default();
                btXacNhanCuoc.Enabled = true;
                bt10K.Enabled = true;
                bt20K.Enabled = true;
                bt50K.Enabled = true;
                bt100K.Enabled = true;
                btExitCuoc.Enabled = true;
                btAIn.Enabled = true;
                btCuocTai.Enabled = false;
                btCuocXiu.Enabled = false;
            }           
        }

        private void tai_xiu_nhapnhay_Tick(object sender, EventArgs e)
        {
            Random ran = new Random();
            int col1 = ran.Next(0, 255);
            int col2 = ran.Next(0, 255);
            int col3 = ran.Next(0, 255);
            if (result >= 3 && result <= 10)
                lbXiu.ForeColor = Color.FromArgb(col1, col2, col3);
            else if (result > 10)
                lbTai.ForeColor = Color.FromArgb(col1, col2, col3);
        }

        private void time10_click(object sender, EventArgs e)
        {
            
            time_cho--;
            lbTime_cho.Text = time_cho.ToString();
            if (time_cho == 0)
            {
                time_trochoi = 60;
                lbTime.Text = "60";
                time60.Start();
                time10.Stop();
                tai_xiu_nhapnhay.Stop();
                lbTime.Show();
                lbTime_cho.Hide();
                time_cho = 5;
                lbTime_cho.Text = "5";
                btCuocXiu.Enabled = true;
                btCuocTai.Enabled = true;
                lbXiu.ForeColor = Color.Red;
                lbTai.ForeColor = Color.Black;
                result = 0;               
            }          
        }

        private void btCuocTai_Click(object sender, EventArgs e)
        {
            btCuocTai.Text = "0";
            btCuocXiu.Enabled = false;
            Show_button();
        }

        private void btCuocXiu_Click(object sender, EventArgs e)
        {
            btCuocXiu.Text = "0";
            btCuocTai.Enabled = false;
            Show_button();
        }

        private void bt10K_Click(object sender, EventArgs e)
        {
            bt20K.BackColor = Color.White;
            bt50K.BackColor = Color.White;
            bt100K.BackColor = Color.White;
            btAIn.BackColor = Color.White;
            if (bt10K.BackColor == Color.Yellow){
                bt10K.BackColor = Color.White;
                if (btCuocTai.Enabled == true)
                    btCuocTai.Text = "0";
                else
                    btCuocXiu.Text = "0";
            }
            else{
                bt10K.BackColor = Color.Yellow;
                if (btCuocTai.Enabled == true)
                    btCuocTai.Text = "10000";
                else
                    btCuocXiu.Text = "10000";
            }
        }

        private void bt20K_Click(object sender, EventArgs e)
        {
            bt10K.BackColor = Color.White;
            bt50K.BackColor = Color.White;
            bt100K.BackColor = Color.White;
            btAIn.BackColor = Color.White;
            if (bt20K.BackColor == Color.Yellow){
                bt20K.BackColor = Color.White;
                if (btCuocTai.Enabled == true)
                    btCuocTai.Text = "0";
                else
                    btCuocXiu.Text = "0";
            }
            else{
                bt20K.BackColor = Color.Yellow;
                if (btCuocTai.Enabled == true)
                    btCuocTai.Text = "20000";
                else
                    btCuocXiu.Text = "20000";
            }
        }

        private void bt50K_Click(object sender, EventArgs e)
        {
            bt10K.BackColor = Color.White;
            bt20K.BackColor = Color.White;
            bt100K.BackColor = Color.White;
            btAIn.BackColor = Color.White;
            if (bt50K.BackColor == Color.Yellow){
                bt50K.BackColor = Color.White;
                if (btCuocTai.Enabled == true)
                    btCuocTai.Text = "0";
                else
                    btCuocXiu.Text = "0";
            }
            else{
                bt50K.BackColor = Color.Yellow;
                if (btCuocTai.Enabled == true)
                    btCuocTai.Text = "50000";
                else
                    btCuocXiu.Text = "50000";
            }
        }

        private void bt100K_Click(object sender, EventArgs e)
        {
            bt10K.BackColor = Color.White;
            bt20K.BackColor = Color.White;
            bt50K.BackColor = Color.White;
            btAIn.BackColor = Color.White;
            if (bt100K.BackColor == Color.Yellow){
                bt100K.BackColor = Color.White;
                if (btCuocTai.Enabled == true)
                    btCuocTai.Text = "0";
                else
                    btCuocXiu.Text = "0";
            }
            else { 
                bt100K.BackColor = Color.Yellow;
                if (btCuocTai.Enabled == true)
                    btCuocTai.Text = "100000";
                else
                    btCuocXiu.Text = "100000";
            }
        }

        private void btExitCuoc_Click(object sender, EventArgs e)
        {           
            Set_Default();
            if(btCuocTai.Enabled == true)
            {
                btCuocTai.Text = "Bet";
                btCuocXiu.Enabled = true;
            }
            else
            {
                btCuocXiu.Text = "Bet";
                btCuocTai.Enabled = true;
            }
        }

        private void btXacNhanCuoc_Click(object sender, EventArgs e)
        {
            int getsodu = int.Parse(lbSodu_User.Text);
            if (btCuocTai.Enabled == true)
            {
                if (bt10K.BackColor == Color.Yellow && getsodu >= 10000)
                {
                    int coin = int.Parse(lbTaiCoin.Text);
                    lbTaiCoin.Text = (coin + 10000).ToString();
                    lbSodu_User.Text = (getsodu - 10000).ToString();
                }
                else if (bt20K.BackColor == Color.Yellow && getsodu >= 20000)
                {
                    int coin = int.Parse(lbTaiCoin.Text);
                    lbTaiCoin.Text = (coin + 20000).ToString();
                    lbSodu_User.Text = (getsodu - 20000).ToString();
                }
                else if (bt50K.BackColor == Color.Yellow && getsodu >= 50000)
                {
                    int coin = int.Parse(lbTaiCoin.Text);
                    lbTaiCoin.Text = (coin + 50000).ToString();
                    lbSodu_User.Text = (getsodu - 50000).ToString();
                }
                else if (bt100K.BackColor == Color.Yellow && getsodu >= 100000)
                {
                    int coin = int.Parse(lbTaiCoin.Text);
                    lbTaiCoin.Text = (coin + 100000).ToString();
                    lbSodu_User.Text = (getsodu - 100000).ToString();
                }
                else if (btAIn.BackColor == Color.Yellow)
                {
                    int coin = int.Parse(lbSodu_User.Text);
                    int coins = int.Parse(lbTaiCoin.Text);
                    lbTaiCoin.Text = (coin+coins).ToString();
                    lbSodu_User.Text = "0";
                }
                else
                {
                    MessageBox.Show("So du trong tai khoan khong du!!!");
                    btCuocTai.Text = "0";
                    return;
                }
            }
            else
            {
                if (bt10K.BackColor == Color.Yellow && getsodu >= 10000)
                {
                    int coin = int.Parse(lbXiuCoin.Text);
                    lbXiuCoin.Text = (coin + 10000).ToString();
                    lbSodu_User.Text = (getsodu - 10000).ToString();
                }
                else if (bt20K.BackColor == Color.Yellow && getsodu >= 20000)
                {
                    int coin = int.Parse(lbXiuCoin.Text);
                    lbXiuCoin.Text = (coin + 20000).ToString();
                    lbSodu_User.Text = (getsodu - 20000).ToString();
                }
                else if (bt50K.BackColor == Color.Yellow && getsodu >= 50000)
                {
                    int coin = int.Parse(lbXiuCoin.Text);
                    lbXiuCoin.Text = (coin + 50000).ToString();
                    lbSodu_User.Text = (getsodu - 50000).ToString();
                }
                else if (bt100K.BackColor == Color.Yellow && getsodu >= 100000)
                {
                    int coin = int.Parse(lbXiuCoin.Text);
                    lbXiuCoin.Text = (coin + 100000).ToString();
                    lbSodu_User.Text = (getsodu - 100000).ToString();
                }
                else if (btAIn.BackColor == Color.Yellow)
                {
                    int coin = int.Parse(lbSodu_User.Text);
                    int coins = int.Parse(lbXiuCoin.Text);
                    lbXiuCoin.Text = (coin + coins).ToString();
                    lbSodu_User.Text = "0";
                }
                else
                {
                    MessageBox.Show("So du trong tai khoan khong du!!!");
                    btCuocXiu.Text = "0";
                    return;
                }
            }
            btXacNhanCuoc.Enabled = false;
            bt10K.Enabled = false;
            bt20K.Enabled = false;
            bt50K.Enabled = false;
            bt100K.Enabled = false;
            btExitCuoc.Enabled = false;
            btAIn.Enabled = false;
        }

        private void btAIn_Click(object sender, EventArgs e)
        {
            bt10K.BackColor = Color.White;
            bt20K.BackColor = Color.White;
            bt50K.BackColor = Color.White;
            bt100K.BackColor = Color.White;
            if (btAIn.BackColor == Color.Yellow)
            {
                btAIn.BackColor = Color.White;
                if (btCuocTai.Enabled == true)
                    btCuocTai.Text = "0";
                else
                    btCuocXiu.Text = "0";
            }
            else
            {
                btAIn.BackColor = Color.Yellow;
                if (btCuocTai.Enabled == true)
                    btCuocTai.Text = lbSodu_User.Text;
                else
                    btCuocXiu.Text = lbSodu_User.Text;
            }
        }

        private void btHuongDan_Click(object sender, EventArgs e)
        {
            
        }
    }
}