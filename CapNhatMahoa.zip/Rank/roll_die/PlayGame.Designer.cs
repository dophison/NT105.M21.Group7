﻿namespace roll_die
{
    partial class PlayGame
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlayGame));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbTime = new System.Windows.Forms.Label();
            this.time60 = new System.Windows.Forms.Timer(this.components);
            this.iconRed_White = new System.Windows.Forms.ImageList(this.components);
            this.listviewResult = new System.Windows.Forms.ListView();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbTai = new System.Windows.Forms.Label();
            this.lbXiu = new System.Windows.Forms.Label();
            this.time10 = new System.Windows.Forms.Timer(this.components);
            this.lbTime_cho = new System.Windows.Forms.Label();
            this.tai_xiu_nhapnhay = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.lbSodu_User = new System.Windows.Forms.Label();
            this.lbName_User = new System.Windows.Forms.Label();
            this.btn_UserInfor = new roll_die.Button_Design_Tron();
            this.btn_HuongDan = new roll_die.Button_Design_Tron();
            this.btCuocTai = new roll_die.Button_Design_Det();
            this.btCuocXiu = new roll_die.Button_Design_Det();
            this.bt10K = new roll_die.Button_Design_Det();
            this.bt20K = new roll_die.Button_Design_Det();
            this.bt50K = new roll_die.Button_Design_Det();
            this.bt100K = new roll_die.Button_Design_Det();
            this.btAIn = new roll_die.Button_Design_Det();
            this.btXacNhanCuoc = new roll_die.Button_Design_Det();
            this.btExitCuoc = new roll_die.Button_Design_Det();
            this.btn_Out = new roll_die.Button_Design_Tron();
            this.btnChat = new roll_die.Button_Design_Tron();
            this.lbRank = new System.Windows.Forms.Label();
            this.tbRankk = new System.Windows.Forms.TextBox();
            this.btRank = new roll_die.Button_Design_Det();
            this.lb_sodu = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(444, 220);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 70);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(491, 144);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(70, 70);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // lbTime
            // 
            this.lbTime.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbTime.Font = new System.Drawing.Font("Gill Sans Ultra Bold Condensed", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.lbTime.Image = global::roll_die.Properties.Resources._60;
            this.lbTime.Location = new System.Drawing.Point(462, 9);
            this.lbTime.Name = "lbTime";
            this.lbTime.Size = new System.Drawing.Size(139, 103);
            this.lbTime.TabIndex = 8;
            this.lbTime.Text = "30";
            // 
            // time60
            // 
            this.time60.Interval = 1000;
            this.time60.Tick += new System.EventHandler(this.time60_click);
            // 
            // iconRed_White
            // 
            this.iconRed_White.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.iconRed_White.ImageSize = new System.Drawing.Size(40, 40);
            this.iconRed_White.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // listviewResult
            // 
            this.listviewResult.BackColor = System.Drawing.Color.White;
            this.listviewResult.ForeColor = System.Drawing.Color.Yellow;
            this.listviewResult.Location = new System.Drawing.Point(128, 319);
            this.listviewResult.Name = "listviewResult";
            this.listviewResult.Scrollable = false;
            this.listviewResult.ShowItemToolTips = true;
            this.listviewResult.Size = new System.Drawing.Size(788, 49);
            this.listviewResult.TabIndex = 8;
            this.listviewResult.UseCompatibleStateImageBehavior = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(542, 220);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(70, 70);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // lbTai
            // 
            this.lbTai.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbTai.Font = new System.Drawing.Font("Stencil", 55.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lbTai.ForeColor = System.Drawing.Color.Black;
            this.lbTai.Image = global::roll_die.Properties.Resources.Tai;
            this.lbTai.Location = new System.Drawing.Point(151, 97);
            this.lbTai.Name = "lbTai";
            this.lbTai.Size = new System.Drawing.Size(200, 101);
            this.lbTai.TabIndex = 10;
            this.lbTai.Text = "Tài";
            // 
            // lbXiu
            // 
            this.lbXiu.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbXiu.Font = new System.Drawing.Font("Stencil", 58.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lbXiu.ForeColor = System.Drawing.Color.Red;
            this.lbXiu.Image = global::roll_die.Properties.Resources.Xiu;
            this.lbXiu.Location = new System.Drawing.Point(671, 97);
            this.lbXiu.Name = "lbXiu";
            this.lbXiu.Size = new System.Drawing.Size(197, 101);
            this.lbXiu.TabIndex = 11;
            this.lbXiu.Text = "Xỉu";
            // 
            // time10
            // 
            this.time10.Interval = 1000;
            this.time10.Tick += new System.EventHandler(this.time10_click);
            // 
            // lbTime_cho
            // 
            this.lbTime_cho.AutoSize = true;
            this.lbTime_cho.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbTime_cho.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbTime_cho.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.lbTime_cho.Image = global::roll_die.Properties.Resources._10;
            this.lbTime_cho.Location = new System.Drawing.Point(592, 123);
            this.lbTime_cho.Name = "lbTime_cho";
            this.lbTime_cho.Size = new System.Drawing.Size(40, 31);
            this.lbTime_cho.TabIndex = 26;
            this.lbTime_cho.Text = "10";
            // 
            // tai_xiu_nhapnhay
            // 
            this.tai_xiu_nhapnhay.Tick += new System.EventHandler(this.tai_xiu_nhapnhay_Tick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(78, 502);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 20);
            this.label3.TabIndex = 32;
            // 
            // lbSodu_User
            // 
            this.lbSodu_User.AutoSize = true;
            this.lbSodu_User.BackColor = System.Drawing.SystemColors.HighlightText;
            this.lbSodu_User.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbSodu_User.Location = new System.Drawing.Point(95, 504);
            this.lbSodu_User.Name = "lbSodu_User";
            this.lbSodu_User.Size = new System.Drawing.Size(20, 23);
            this.lbSodu_User.TabIndex = 33;
            this.lbSodu_User.Text = "0";
            // 
            // lbName_User
            // 
            this.lbName_User.AutoSize = true;
            this.lbName_User.BackColor = System.Drawing.SystemColors.HighlightText;
            this.lbName_User.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbName_User.Location = new System.Drawing.Point(12, 465);
            this.lbName_User.Name = "lbName_User";
            this.lbName_User.Size = new System.Drawing.Size(161, 23);
            this.lbName_User.TabIndex = 34;
            this.lbName_User.Text = "Name: Anonymous";
            // 
            // btn_UserInfor
            // 
            this.btn_UserInfor.FlatAppearance.BorderSize = 0;
            this.btn_UserInfor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UserInfor.Image = global::roll_die.Properties.Resources.user2;
            this.btn_UserInfor.Location = new System.Drawing.Point(43, 27);
            this.btn_UserInfor.Name = "btn_UserInfor";
            this.btn_UserInfor.Size = new System.Drawing.Size(61, 62);
            this.btn_UserInfor.TabIndex = 37;
            this.btn_UserInfor.UseVisualStyleBackColor = true;
            this.btn_UserInfor.Click += new System.EventHandler(this.btn_UserInfor_Click);
            // 
            // btn_HuongDan
            // 
            this.btn_HuongDan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_HuongDan.FlatAppearance.BorderSize = 0;
            this.btn_HuongDan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_HuongDan.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_HuongDan.Location = new System.Drawing.Point(43, 106);
            this.btn_HuongDan.Name = "btn_HuongDan";
            this.btn_HuongDan.Size = new System.Drawing.Size(61, 61);
            this.btn_HuongDan.TabIndex = 38;
            this.btn_HuongDan.Text = "?";
            this.btn_HuongDan.UseVisualStyleBackColor = false;
            this.btn_HuongDan.Click += new System.EventHandler(this.btn_HuongDan_Click);
            // 
            // btCuocTai
            // 
            this.btCuocTai.BackColor = System.Drawing.Color.Fuchsia;
            this.btCuocTai.BackgroundColor = System.Drawing.Color.Fuchsia;
            this.btCuocTai.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btCuocTai.BorderRadius = 20;
            this.btCuocTai.BorderSize = 0;
            this.btCuocTai.FlatAppearance.BorderSize = 0;
            this.btCuocTai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCuocTai.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btCuocTai.ForeColor = System.Drawing.Color.Black;
            this.btCuocTai.Location = new System.Drawing.Point(182, 214);
            this.btCuocTai.Name = "btCuocTai";
            this.btCuocTai.Size = new System.Drawing.Size(132, 47);
            this.btCuocTai.TabIndex = 39;
            this.btCuocTai.Text = "Bet";
            this.btCuocTai.TextColor = System.Drawing.Color.Black;
            this.btCuocTai.UseVisualStyleBackColor = false;
            this.btCuocTai.Click += new System.EventHandler(this.btCuocTai_Click);
            // 
            // btCuocXiu
            // 
            this.btCuocXiu.BackColor = System.Drawing.Color.Fuchsia;
            this.btCuocXiu.BackgroundColor = System.Drawing.Color.Fuchsia;
            this.btCuocXiu.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btCuocXiu.BorderRadius = 20;
            this.btCuocXiu.BorderSize = 0;
            this.btCuocXiu.FlatAppearance.BorderSize = 0;
            this.btCuocXiu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCuocXiu.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btCuocXiu.ForeColor = System.Drawing.Color.Black;
            this.btCuocXiu.Location = new System.Drawing.Point(700, 220);
            this.btCuocXiu.Name = "btCuocXiu";
            this.btCuocXiu.Size = new System.Drawing.Size(132, 47);
            this.btCuocXiu.TabIndex = 40;
            this.btCuocXiu.Text = "Bet";
            this.btCuocXiu.TextColor = System.Drawing.Color.Black;
            this.btCuocXiu.UseVisualStyleBackColor = false;
            this.btCuocXiu.Click += new System.EventHandler(this.btCuocXiu_Click);
            // 
            // bt10K
            // 
            this.bt10K.BackColor = System.Drawing.Color.Salmon;
            this.bt10K.BackgroundColor = System.Drawing.Color.Salmon;
            this.bt10K.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.bt10K.BorderRadius = 20;
            this.bt10K.BorderSize = 0;
            this.bt10K.FlatAppearance.BorderSize = 0;
            this.bt10K.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt10K.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt10K.ForeColor = System.Drawing.Color.Black;
            this.bt10K.Location = new System.Drawing.Point(256, 393);
            this.bt10K.Name = "bt10K";
            this.bt10K.Size = new System.Drawing.Size(95, 41);
            this.bt10K.TabIndex = 41;
            this.bt10K.Text = "10K";
            this.bt10K.TextColor = System.Drawing.Color.Black;
            this.bt10K.UseVisualStyleBackColor = false;
            this.bt10K.Click += new System.EventHandler(this.bt10K_Click);
            // 
            // bt20K
            // 
            this.bt20K.BackColor = System.Drawing.Color.Salmon;
            this.bt20K.BackgroundColor = System.Drawing.Color.Salmon;
            this.bt20K.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.bt20K.BorderRadius = 20;
            this.bt20K.BorderSize = 0;
            this.bt20K.FlatAppearance.BorderSize = 0;
            this.bt20K.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt20K.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt20K.ForeColor = System.Drawing.Color.Black;
            this.bt20K.Location = new System.Drawing.Point(410, 393);
            this.bt20K.Name = "bt20K";
            this.bt20K.Size = new System.Drawing.Size(95, 41);
            this.bt20K.TabIndex = 42;
            this.bt20K.Text = "20K";
            this.bt20K.TextColor = System.Drawing.Color.Black;
            this.bt20K.UseVisualStyleBackColor = false;
            this.bt20K.Click += new System.EventHandler(this.bt20K_Click);
            // 
            // bt50K
            // 
            this.bt50K.BackColor = System.Drawing.Color.Salmon;
            this.bt50K.BackgroundColor = System.Drawing.Color.Salmon;
            this.bt50K.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.bt50K.BorderRadius = 20;
            this.bt50K.BorderSize = 0;
            this.bt50K.FlatAppearance.BorderSize = 0;
            this.bt50K.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt50K.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt50K.ForeColor = System.Drawing.Color.Black;
            this.bt50K.Location = new System.Drawing.Point(555, 393);
            this.bt50K.Name = "bt50K";
            this.bt50K.Size = new System.Drawing.Size(95, 41);
            this.bt50K.TabIndex = 43;
            this.bt50K.Text = "50K";
            this.bt50K.TextColor = System.Drawing.Color.Black;
            this.bt50K.UseVisualStyleBackColor = false;
            this.bt50K.Click += new System.EventHandler(this.bt50K_Click);
            // 
            // bt100K
            // 
            this.bt100K.BackColor = System.Drawing.Color.Salmon;
            this.bt100K.BackgroundColor = System.Drawing.Color.Salmon;
            this.bt100K.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.bt100K.BorderRadius = 20;
            this.bt100K.BorderSize = 0;
            this.bt100K.FlatAppearance.BorderSize = 0;
            this.bt100K.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt100K.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bt100K.ForeColor = System.Drawing.Color.Black;
            this.bt100K.Location = new System.Drawing.Point(700, 393);
            this.bt100K.Name = "bt100K";
            this.bt100K.Size = new System.Drawing.Size(95, 41);
            this.bt100K.TabIndex = 44;
            this.bt100K.Text = "100K";
            this.bt100K.TextColor = System.Drawing.Color.Black;
            this.bt100K.UseVisualStyleBackColor = false;
            this.bt100K.Click += new System.EventHandler(this.bt100K_Click);
            // 
            // btAIn
            // 
            this.btAIn.BackColor = System.Drawing.Color.Violet;
            this.btAIn.BackgroundColor = System.Drawing.Color.Violet;
            this.btAIn.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btAIn.BorderRadius = 20;
            this.btAIn.BorderSize = 0;
            this.btAIn.FlatAppearance.BorderSize = 0;
            this.btAIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAIn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btAIn.ForeColor = System.Drawing.Color.Black;
            this.btAIn.Location = new System.Drawing.Point(293, 481);
            this.btAIn.Name = "btAIn";
            this.btAIn.Size = new System.Drawing.Size(113, 46);
            this.btAIn.TabIndex = 45;
            this.btAIn.Text = "ALL IN";
            this.btAIn.TextColor = System.Drawing.Color.Black;
            this.btAIn.UseVisualStyleBackColor = false;
            this.btAIn.Click += new System.EventHandler(this.btAIn_Click);
            // 
            // btXacNhanCuoc
            // 
            this.btXacNhanCuoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btXacNhanCuoc.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btXacNhanCuoc.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btXacNhanCuoc.BorderRadius = 20;
            this.btXacNhanCuoc.BorderSize = 0;
            this.btXacNhanCuoc.FlatAppearance.BorderSize = 0;
            this.btXacNhanCuoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btXacNhanCuoc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btXacNhanCuoc.ForeColor = System.Drawing.Color.Black;
            this.btXacNhanCuoc.Location = new System.Drawing.Point(444, 465);
            this.btXacNhanCuoc.Name = "btXacNhanCuoc";
            this.btXacNhanCuoc.Size = new System.Drawing.Size(168, 62);
            this.btXacNhanCuoc.TabIndex = 46;
            this.btXacNhanCuoc.Text = "Xác Nhận Cược";
            this.btXacNhanCuoc.TextColor = System.Drawing.Color.Black;
            this.btXacNhanCuoc.UseVisualStyleBackColor = false;
            this.btXacNhanCuoc.Click += new System.EventHandler(this.btXacNhanCuoc_Click);
            // 
            // btExitCuoc
            // 
            this.btExitCuoc.BackColor = System.Drawing.Color.Red;
            this.btExitCuoc.BackgroundColor = System.Drawing.Color.Red;
            this.btExitCuoc.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btExitCuoc.BorderRadius = 20;
            this.btExitCuoc.BorderSize = 0;
            this.btExitCuoc.FlatAppearance.BorderSize = 0;
            this.btExitCuoc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btExitCuoc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btExitCuoc.ForeColor = System.Drawing.Color.Black;
            this.btExitCuoc.Location = new System.Drawing.Point(649, 481);
            this.btExitCuoc.Name = "btExitCuoc";
            this.btExitCuoc.Size = new System.Drawing.Size(113, 46);
            this.btExitCuoc.TabIndex = 47;
            this.btExitCuoc.Text = "EXIT";
            this.btExitCuoc.TextColor = System.Drawing.Color.Black;
            this.btExitCuoc.UseVisualStyleBackColor = false;
            this.btExitCuoc.Click += new System.EventHandler(this.btExitCuoc_Click);
            // 
            // btn_Out
            // 
            this.btn_Out.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btn_Out.FlatAppearance.BorderSize = 0;
            this.btn_Out.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Out.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Out.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Out.Location = new System.Drawing.Point(934, 474);
            this.btn_Out.Name = "btn_Out";
            this.btn_Out.Size = new System.Drawing.Size(69, 57);
            this.btn_Out.TabIndex = 48;
            this.btn_Out.Text = "Out";
            this.btn_Out.UseVisualStyleBackColor = false;
            this.btn_Out.Click += new System.EventHandler(this.btn_Out_Click);
            // 
            // btnChat
            // 
            this.btnChat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnChat.FlatAppearance.BorderSize = 0;
            this.btnChat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChat.Font = new System.Drawing.Font("MV Boli", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnChat.Location = new System.Drawing.Point(21, 187);
            this.btnChat.Name = "btnChat";
            this.btnChat.Size = new System.Drawing.Size(108, 59);
            this.btnChat.TabIndex = 49;
            this.btnChat.Text = "Chat";
            this.btnChat.UseVisualStyleBackColor = false;
            this.btnChat.Click += new System.EventHandler(this.btnChat_Click);
            // 
            // lbRank
            // 
            this.lbRank.AutoSize = true;
            this.lbRank.BackColor = System.Drawing.SystemColors.HighlightText;
            this.lbRank.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbRank.Location = new System.Drawing.Point(900, 39);
            this.lbRank.Name = "lbRank";
            this.lbRank.Size = new System.Drawing.Size(117, 23);
            this.lbRank.TabIndex = 50;
            this.lbRank.Text = "Top 3 Đại Gia";
            // 
            // tbRankk
            // 
            this.tbRankk.Location = new System.Drawing.Point(900, 80);
            this.tbRankk.Multiline = true;
            this.tbRankk.Name = "tbRankk";
            this.tbRankk.Size = new System.Drawing.Size(117, 62);
            this.tbRankk.TabIndex = 51;
            // 
            // btRank
            // 
            this.btRank.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.btRank.BackgroundColor = System.Drawing.Color.MediumSlateBlue;
            this.btRank.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btRank.BorderRadius = 20;
            this.btRank.BorderSize = 0;
            this.btRank.FlatAppearance.BorderSize = 0;
            this.btRank.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btRank.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btRank.ForeColor = System.Drawing.Color.White;
            this.btRank.Location = new System.Drawing.Point(916, 163);
            this.btRank.Name = "btRank";
            this.btRank.Size = new System.Drawing.Size(87, 51);
            this.btRank.TabIndex = 52;
            this.btRank.Text = "Rank";
            this.btRank.TextColor = System.Drawing.Color.White;
            this.btRank.UseVisualStyleBackColor = false;
            this.btRank.Click += new System.EventHandler(this.btRank_Click);
            // 
            // lb_sodu
            // 
            this.lb_sodu.AutoSize = true;
            this.lb_sodu.BackColor = System.Drawing.SystemColors.HighlightText;
            this.lb_sodu.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lb_sodu.Location = new System.Drawing.Point(10, 504);
            this.lb_sodu.Name = "lb_sodu";
            this.lb_sodu.Size = new System.Drawing.Size(62, 23);
            this.lb_sodu.TabIndex = 53;
            this.lb_sodu.Text = "Số dư:";
            // 
            // PlayGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BackgroundImage = global::roll_die.Properties.Resources.BackGround;
            this.ClientSize = new System.Drawing.Size(1049, 540);
            this.Controls.Add(this.lb_sodu);
            this.Controls.Add(this.btRank);
            this.Controls.Add(this.tbRankk);
            this.Controls.Add(this.lbRank);
            this.Controls.Add(this.btnChat);
            this.Controls.Add(this.btn_Out);
            this.Controls.Add(this.btExitCuoc);
            this.Controls.Add(this.btXacNhanCuoc);
            this.Controls.Add(this.btAIn);
            this.Controls.Add(this.bt100K);
            this.Controls.Add(this.bt50K);
            this.Controls.Add(this.bt20K);
            this.Controls.Add(this.bt10K);
            this.Controls.Add(this.btCuocXiu);
            this.Controls.Add(this.btCuocTai);
            this.Controls.Add(this.btn_HuongDan);
            this.Controls.Add(this.btn_UserInfor);
            this.Controls.Add(this.lbName_User);
            this.Controls.Add(this.lbSodu_User);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbTime_cho);
            this.Controls.Add(this.lbXiu);
            this.Controls.Add(this.lbTai);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.listviewResult);
            this.Controls.Add(this.lbTime);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.Name = "PlayGame";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private Label lbTime;
        private System.Windows.Forms.Timer time60;
        private ListView listviewResult;
        public ImageList iconRed_White;
        private PictureBox pictureBox2;
        private Label lbTai;
        private Label lbXiu;
        private System.Windows.Forms.Timer time10;
        private Label lbTime_cho;
        private System.Windows.Forms.Timer tai_xiu_nhapnhay;
        private Label label3;
        private Label lbSodu_User;
        private Label lbName_User;
        private Button_Design_Tron btn_UserInfor;
        private Button_Design_Tron btn_HuongDan;
        private Button_Design_Det btCuocTai;
        private Button_Design_Det btCuocXiu;
        private Button_Design_Det bt10K;
        private Button_Design_Det bt20K;
        private Button_Design_Det bt50K;
        private Button_Design_Det bt100K;
        private Button_Design_Det btAIn;
        private Button_Design_Det btXacNhanCuoc;
        private Button_Design_Det btExitCuoc;
        private Button_Design_Tron btn_Out;
        private Button_Design_Tron btnChat;
        private Label lbRank;
        private TextBox tbRankk;
        private Button_Design_Det btRank;
        private Label lb_sodu;
    }
}