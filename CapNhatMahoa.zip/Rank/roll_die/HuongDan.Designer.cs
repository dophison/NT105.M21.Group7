﻿namespace roll_die
{
    partial class HuongDan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_Instruction = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbx_Instruction
            // 
            this.tbx_Instruction.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.tbx_Instruction.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbx_Instruction.Font = new System.Drawing.Font("MV Boli", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbx_Instruction.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.tbx_Instruction.Location = new System.Drawing.Point(308, 111);
            this.tbx_Instruction.Multiline = true;
            this.tbx_Instruction.Name = "tbx_Instruction";
            this.tbx_Instruction.ReadOnly = true;
            this.tbx_Instruction.Size = new System.Drawing.Size(672, 488);
            this.tbx_Instruction.TabIndex = 0;
            this.tbx_Instruction.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Curlz MT", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(384, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(328, 89);
            this.label1.TabIndex = 1;
            this.label1.Text = "Instruction";
            // 
            // HuongDan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::roll_die.Properties.Resources._283906651_371671821499121_2439104192388796634_n;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1088, 643);
            this.Controls.Add(this.tbx_Instruction);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Name = "HuongDan";
            this.Text = "HuongDan";
            this.Load += new System.EventHandler(this.HuongDan_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox tbx_Instruction;
        private Label label1;
    }
}