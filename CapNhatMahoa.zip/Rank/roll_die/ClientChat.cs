﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace roll_die
{
    public partial class ClientChat : Form
    {
        public NetComm.Client clientchat; //The clientchat object used for the communication
        public ClientChat()
        {
            InitializeComponent();
            clientchat = new NetComm.Client();
            clientchat.Connected += new NetComm.Client.ConnectedEventHandler(clientchat_Connected);
            //clientchat.Disconnected += new NetComm.Client.DisconnectedEventHandler(clientchat_Disconnected);
            clientchat.DataReceived += new NetComm.Client.DataReceivedEventHandler(clientchat_DataReceived);
            
        }

        
        private void MainDisplay_Load(object sender, EventArgs e)
        {
            //; //Initialize the clientchat object

            //Adding event handling methods for the clientchat
            
        }

        public void Action()
        {

            //clientchat.Connect("localhost", 2022, "Jack");
            //clientchat.Connect("127.0.0.1", 2020, "Jack");
            //Connecting to the host
            //clientchat.Connect("localhost", 2020, "Jack"); //Connecting to the host (on the same machine) with port 2020 and ID "Jack"
        }

        

        void clientchat_DataReceived(byte[] Data, string ID)
        {
            Log.AppendText(ID + ConvertBytesToString(Data) + "\r\n"); //Updates the log with the current connection state
            //string temp =ID+ConvertBytesToString(Data)+"\r\n";
            //Log.Text+=ConvertBytesToString(ConvertStringToBytes(temp));
        }

        void clientchat_Disconnected()
        {
            /*Log.AppendText("Disconnected from host!" + Environment.NewLine);*/ //Updates the log with the current connection state
        }

        void clientchat_Connected()
        {
            /*Log.AppendText("Connected succesfully!" + Environment.NewLine);*/ //Updates the log with the current connection state
        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            clientchat.SendData(ConvertStringToBytes(ChatMessage.Text)); //Sends the message to the host
            ChatMessage.Clear(); //Clears the chatmessage textbox text
        }

        string ConvertBytesToString(byte[] bytes)
        {
            return ASCIIEncoding.ASCII.GetString(bytes);
        }

        byte[] ConvertStringToBytes(string str)
        {
            return ASCIIEncoding.ASCII.GetBytes(str);
        }

        private void ClientChat_FormClosing(object sender, FormClosingEventArgs e)
        {
            clientchat.Disconnected += new NetComm.Client.DisconnectedEventHandler(clientchat_Disconnected);
            if (clientchat.isConnected) clientchat.Disconnect(); //Disconnects if the clientchat is connected, closing the communication thread
            
        }
    }
}
