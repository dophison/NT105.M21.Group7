﻿namespace roll_die
{
    partial class UserInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbRank = new System.Windows.Forms.Label();
            this.tbMoney = new System.Windows.Forms.TextBox();
            this.tbRank = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Image = global::roll_die.Properties.Resources.Image_User2;
            this.button1.Location = new System.Drawing.Point(116, 118);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(298, 374);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Curlz MT", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(420, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(494, 89);
            this.label1.TabIndex = 1;
            this.label1.Text = "User Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Location = new System.Drawing.Point(429, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 40);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name:";
            // 
            // tbUsername
            // 
            this.tbUsername.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tbUsername.ForeColor = System.Drawing.Color.Red;
            this.tbUsername.Location = new System.Drawing.Point(567, 207);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(296, 40);
            this.tbUsername.TabIndex = 6;
            this.tbUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Location = new System.Drawing.Point(429, 287);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 40);
            this.label4.TabIndex = 8;
            this.label4.Text = "Money:";
            // 
            // lbRank
            // 
            this.lbRank.AutoSize = true;
            this.lbRank.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbRank.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbRank.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbRank.Location = new System.Drawing.Point(429, 374);
            this.lbRank.Name = "lbRank";
            this.lbRank.Size = new System.Drawing.Size(105, 40);
            this.lbRank.TabIndex = 9;
            this.lbRank.Text = "Level:";
            // 
            // tbMoney
            // 
            this.tbMoney.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tbMoney.ForeColor = System.Drawing.Color.Red;
            this.tbMoney.Location = new System.Drawing.Point(567, 287);
            this.tbMoney.Name = "tbMoney";
            this.tbMoney.Size = new System.Drawing.Size(296, 40);
            this.tbMoney.TabIndex = 11;
            this.tbMoney.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRank
            // 
            this.tbRank.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tbRank.ForeColor = System.Drawing.Color.Cyan;
            this.tbRank.Location = new System.Drawing.Point(567, 374);
            this.tbRank.Name = "tbRank";
            this.tbRank.Size = new System.Drawing.Size(296, 40);
            this.tbRank.TabIndex = 12;
            this.tbRank.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // UserInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::roll_die.Properties.Resources.KhungUser;
            this.ClientSize = new System.Drawing.Size(995, 648);
            this.Controls.Add(this.tbRank);
            this.Controls.Add(this.tbMoney);
            this.Controls.Add(this.lbRank);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbUsername);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "UserInformation";
            this.Text = "UserInformation";
            this.Load += new System.EventHandler(this.UserInformation_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button button1;
        private Label label1;
        private Label label2;
        private TextBox tbUsername;
        private Label label4;
        private Label lbRank;
        private TextBox tbMoney;
        private TextBox tbRank;
    }
}