﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace roll_die
{
    public partial class HuongDan : Form
    {
        public HuongDan()
        {
            InitializeComponent();
        }

        private void HuongDan_Load(object sender, EventArgs e)
        {
            tbx_Instruction.Text ="~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~\r\n"+
                "  * Chọn đặt cược vô tài hoặc xỉu.\r\n" +
                "  * Chọn số tiền muốn đặt cược.\r\n" +
                "  * Bấm xác nhận.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n"+
                " ~.~ Chúc các bạn may mắn ~.~ \r\n " +
                "~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~.~";
                
            tbx_Instruction.BackColor = System.Drawing.Color.Black;
            tbx_Instruction.ForeColor = System.Drawing.Color.CadetBlue;
        }
    }
}
